$(document).ready(function(){
	$('.bxslider').bxSlider({
	  mode: 'fade',
	  captions: true,
	  auto: false,
	  autoControls: false,
	  pause: 5000
	});
});
